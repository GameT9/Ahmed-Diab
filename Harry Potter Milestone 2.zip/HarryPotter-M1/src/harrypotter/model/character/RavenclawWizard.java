package harrypotter.model.character;

public class RavenclawWizard extends Wizard implements Champion {

	public RavenclawWizard(String name) {
		
		super(name, 750, 700);

	}

	public void useTrait() {

		// TODO: M2
		getListener().onRavenclawTrait();

	}

}
