package harrypotter.model.character;

import java.util.EventListener;

import harrypotter.model.world.Direction;

public interface WizardListener extends EventListener{
	void onGryffindorTrait();
	void onSlytherinTrait(Direction d);
	void onHufflepuffTrait();
	Object onRavenclawTrait();

}
