package harrypotter.model.magic;

public abstract class Spell {

	private String name;
	private int cost;
	private int coolDown;
	private int defaultCooldown;

	public Spell(String name, int cost, int defaultCoolDown) {

		this.name = name;
		this.cost = cost;
		this.defaultCooldown = defaultCoolDown;
		coolDown = 0;

	}

	public String getName() {

		return name;

	}

	public int getCost() {

		return cost;

	}

	public int getCoolDown() {

		return coolDown;

	}

	public int getDefaultCooldown() {

		return defaultCooldown;

	}

	public void setCoolDown(int coolDown) {

		this.coolDown = coolDown;

	}

}
