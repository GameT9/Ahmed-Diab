package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.Potion;
import harrypotter.model.world.Cell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.CollectibleCell;
import harrypotter.model.world.Direction;
import harrypotter.model.world.EmptyCell;
import harrypotter.model.world.PhysicalObstacle;
import harrypotter.model.world.ObstacleCell;

import java.awt.Point;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class FirstTask extends Task {
	private ArrayList<Point>markedCells;
	private ArrayList<Champion>winners;

	public FirstTask(ArrayList<Champion> champions) throws IOException {

		super(champions);
		Collections.shuffle(champions);
		generateMap();
		setCurrentChamp(getChampions().get(0));
		markedCells= new ArrayList<Point>();
		markCells();

	}

	public void generateMap() {

		Cell[][] map = getMap();

		initializeAllEmpty();

		allocateChampions();

		int count = 0;
		while (count < 40) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell
					&& !(randomX == 4 && randomY == 4)) {

				int hp = (int) ((Math.random() * 101) + 200);
				map[randomX][randomY] = new ObstacleCell(new PhysicalObstacle(hp));
				count++;

			}

		}

		allocatePotions();

	}

	public void allocatePotions() {

		Cell[][] map = getMap();

		ArrayList<Potion> potions = getPotions();

		int i = 0;
		while (i < 10) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell
					&& !(randomX == 4 && randomY == 4)) {

				int r = (int) (Math.random() * potions.size());
				map[randomX][randomY] = new CollectibleCell(potions.get(r));
				i++;

			}

		}
	}
	void markCells() {
		markedCells= new ArrayList<Point>();
		for (int i = 0; i < 2; i++) {
			int currentLocationX = ((Wizard) getCurrentChamp()).getLocation().x;
			int currentLocationY = ((Wizard) getCurrentChamp()).getLocation().y;
			Random r1 = new Random();
			Random r2 = new Random();
			int i1 = r1.nextInt(10);
			int j1 = r2.nextInt(10);
			while ((i1 != currentLocationX && j1 != currentLocationY - 1)
					|| (i1 != currentLocationX && j1 != currentLocationY + 1)
					|| (i1 != currentLocationX - 1 && j1 != currentLocationY)
					|| (i1 != currentLocationX + 1 && j1 != currentLocationY)) {
				 r1 = new Random();
				 r2 = new Random();
				 i1 = r1.nextInt(10);
				 j1 = r2.nextInt(10);

			}
			
			markedCells.add(new Point(i1,j1));
		}
	}
	void fire() {
		for(int i=0;i<markedCells.size();i++){
			if(getMap()[markedCells.get(i).x][markedCells.get(i).y] instanceof ChampionCell)
				((Wizard)getCurrentChamp()).setHp(((Wizard)getCurrentChamp()).getHp()-150);
		}

	}

	@Override
	public void onGryffindorTrait() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSlytherinTrait(Direction d) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHufflepuffTrait() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object onRavenclawTrait() {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Point> getMarkedCells() {
		return markedCells;
	}

	public void setMarkedCells(ArrayList<Point> markedCells) {
		this.markedCells = markedCells;
	}

	public ArrayList<Champion> getWinners() {
		return winners;
	}

	public void setWinners(ArrayList<Champion> winners) {
		this.winners = winners;
	}

}
