package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.HufflepuffWizard;
import harrypotter.model.character.RavenclawWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.character.WizardListener;
import harrypotter.model.magic.Potion;
import harrypotter.model.magic.Spell;
import harrypotter.model.world.Cell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.CollectibleCell;
import harrypotter.model.world.Direction;
import harrypotter.model.world.EmptyCell;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public abstract class Task implements WizardListener {

	private ArrayList<Champion> champions;
	private Cell[][] map;
	private Champion currentChamp;
	private int allowedMoves;
	private boolean traitActivated;
	private ArrayList<Potion> potions;
	private TaskListener listener;
	private GryffindorWizard g = new GryffindorWizard("A");
	private HufflepuffWizard h = new HufflepuffWizard("B");
	private RavenclawWizard r = new RavenclawWizard("C");
	private SlytherinWizard s = new SlytherinWizard("D");

	public Task(ArrayList<Champion> champions) throws IOException {

		this.champions = champions;
		map = new Cell[10][10];
		potions = new ArrayList<Potion>();
		loadPotions("potions.csv");
		allowedMoves = 1;

	}

	public abstract void generateMap() throws IOException;

	public ArrayList<Champion> getChampions() {

		return champions;

	}

	public Cell[][] getMap() {

		return map;

	}

	public Champion getCurrentChamp() {

		return currentChamp;

	}

	public ArrayList<Potion> getPotions() {

		return potions;

	}

	public int getAllowedMoves() {

		return allowedMoves;

	}

	public boolean isTraitActivated() {

		return traitActivated;

	}

	public void setCurrentChamp(Champion currentChamp) {

		this.currentChamp = currentChamp;

	}

	public void setAllowedMoves(int allowedMoves) {

		this.allowedMoves = allowedMoves;

	}

	public void setTraitActivated(boolean traitActivated) {

		this.traitActivated = traitActivated;

	}

	private void loadPotions(String filePath) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();

		while (line != null) {

			String[] content = line.split(",");
			potions.add(new Potion(content[0], Integer.parseInt(content[1])));
			line = br.readLine();

		}

		br.close();

	}

	public void initializeAllEmpty() {

		for (int i = 0; i < map.length; i++) {

			for (int j = 0; j < map[i].length; j++) {

				map[i][j] = new EmptyCell();

			}

		}

	}

	public void allocateChampions() {

		for (int i = 0; i < champions.size(); i++) {

			Champion champ = champions.get(i);

			if (i == 0) {

				map[9][0] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(9, 0));

			}

			else if (i == 1) {

				map[9][9] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(9, 9));

			} else if (i == 2) {

				map[0][9] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(0, 9));

			} else {

				map[0][0] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(0, 0));

			}

		}

	}

	public void allocatePotions() {

		int i = 0;
		while (i < 10) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell) {

				int r = (int) (Math.random() * potions.size());
				map[randomX][randomY] = new CollectibleCell(potions.get(r));
				i++;

			}

		}

	}

	Point getTargetPoint(Direction d) {
		switch (d) {
		case FORWARD:
			return new Point(((Wizard) getCurrentChamp()).getLocation().x,
					((Wizard) getCurrentChamp()).getLocation().y - 1);
		case BACKWARD:
			return new Point(((Wizard) getCurrentChamp()).getLocation().x,
					((Wizard) getCurrentChamp()).getLocation().y + 1);
		case RIGHT:
			return new Point(((Wizard) getCurrentChamp()).getLocation().x + 1,
					((Wizard) getCurrentChamp()).getLocation().y);
		case LEFT:
			return new Point(((Wizard) getCurrentChamp()).getLocation().x - 1,
					((Wizard) getCurrentChamp()).getLocation().y);
		default:
			return null;
		}
	}
	void useSpell(Spell s){
		s.setCoolDown(s.getDefaultCooldown());
		((Wizard)currentChamp).setIp(((Wizard)currentChamp).getIp()-s.getCost());
		
	}

	public TaskListener getListener() {
		return listener;
	}

	public void setListener(TaskListener listener) {
		this.listener = listener;
	}
	
	void endTurn(){
		if(allowedMoves==0){
			
		}
			
	}
	void usePotion(Potion p){
		((Wizard)currentChamp).setIp(((Wizard)currentChamp).getIp()+p.getAmount());
	}

}
