package harrypotter.model.tournament;

import java.util.ArrayList;
import java.util.EventListener;

import harrypotter.model.character.Champion;

public interface TaskListener extends EventListener {
	void onFinishingFirstTask(ArrayList<Champion> winners);
	void onFinishingSecondTask(ArrayList<Champion>winners);
	void onFinishingThirdTask(Champion winner);
}
