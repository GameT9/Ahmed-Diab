package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.magic.DamagingSpell;
import harrypotter.model.magic.HealingSpell;
import harrypotter.model.magic.RelocatingSpell;
import harrypotter.model.magic.Spell;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Tournament  implements TaskListener{

	private ArrayList<Champion> champions;
	private ArrayList<Spell> spells;
	private FirstTask firstTask;
	private SecondTask secondTask;
	private ThirdTask thirdTask;

	public Tournament() throws IOException {

		champions = new ArrayList<Champion>();
		spells = new ArrayList<Spell>();
		loadSpells("spells.csv");

	}
	void beginTournament() throws IOException{
		firstTask= new FirstTask(champions);
		
	}

	private void loadSpells(String filePath) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();

		while (line != null) {

			String[] content = line.split(",");

			int cost = Integer.parseInt(content[2]);
			int defaultCoolDown = Integer.parseInt(content[4]);
			int amount = Integer.parseInt(content[3]);

			switch (content[0]) {

			case "DMG":

				spells.add(new DamagingSpell(content[1], cost, defaultCoolDown,
						amount));
				break;

			case "HEL":

				spells.add(new HealingSpell(content[1], cost, defaultCoolDown,
						amount));
				break;

			case "REL":

				spells.add(new RelocatingSpell(content[1], cost,
						defaultCoolDown, amount));
				break;

			}

			line = br.readLine();

		}

		br.close();

	}

	public ArrayList<Champion> getChampions() {

		return champions;

	}

	public ArrayList<Spell> getSpells() {

		return spells;

	}

	public FirstTask getFirstTask() {

		return firstTask;

	}

	public SecondTask getSecondTask() {

		return secondTask;

	}

	public ThirdTask getThirdTask() {

		return thirdTask;

	}
	

	@Override
	public void onFinishingFirstTask(ArrayList<Champion> winners) {
		
	}

	@Override
	public void onFinishingSecondTask(ArrayList<Champion> winners) {
	
		
	}

	@Override
	public void onFinishingThirdTask(Champion winner) {
		
		
	}

}
