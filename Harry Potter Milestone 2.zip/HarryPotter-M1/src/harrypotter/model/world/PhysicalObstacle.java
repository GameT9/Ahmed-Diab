package harrypotter.model.world;

public class PhysicalObstacle extends Obstacle {

	public PhysicalObstacle(int hp) {

		super(hp);

	}

}
